# STAGE003 offline bundle

内容：腿式 state1 与轮式 state1 R1 的真实 50 Hz 轨迹、必要脚本、机器人/场景资产、
回放入口。不含 Lux3D 生成、密钥或 GB 级缓存。

依赖：Python 3 + mujoco + numpy + Pillow；ffmpeg（仅 `all` 模式需要）。

用法：
```bash
./run_replay.sh wheel   # 渲染轮式回放（约 10 s 轨迹）
./run_replay.sh leg     # 渲染腿式回放（约 58.6 s 轨迹）
./run_replay.sh all     # 两者 + 1920x1080 并排（轮式结束后冻结最后一帧）
```
输出在 `replay/`。轨迹来自：
- leg: s4_state1f（nominal，初态 1）
- wheel: s5_wheel_rec/record_00（同初态，R1 0.30 m/s）
