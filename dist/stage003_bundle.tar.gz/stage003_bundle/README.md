# STAGE003 offline bundle (record-fix rebuild)

内容：腿式 state1 与轮式 state1 R1 的**修复后**真实 50 Hz 轨迹、必要脚本、机器人/场景
资产、回放入口。不含 Lux3D 生成、密钥或 GB 级缓存。

依赖：Python 3 + mujoco + numpy + Pillow；ffmpeg（仅 `all` 模式需要）。

用法：
```bash
./run_replay.sh wheel   # 轮式，14.72 s 真实执行全程（736 帧）
./run_replay.sh leg     # 腿式，58.56 s（2929 帧）
./run_replay.sh all     # 两者 + 1920x1080 并排；轮式播到 14.72 s 结束后才冻结末帧
```
输出在 `replay/`。轨迹来自 `fix_leg_state1` 与 `fix_s5_wheel2/record_00`；
记录器已在采样与入队时拷贝数组，帧不再被后续仿真步覆盖。
