#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ -n "${PYTHON:-}" ]; then PY="$PYTHON"
elif [ -x /opt/lunar/bin/python ]; then PY=/opt/lunar/bin/python
else PY=python3
fi
MODE=${1:-all}
mkdir -p replay
render() { MUJOCO_GL=${MUJOCO_GL:-egl} "$PY" scripts/v3_replay.py --run "$1" --out "replay/$1.mp4"; }
case "$MODE" in
  leg) render leg ;;
  wheel) render wheel ;;
  all)
    render leg
    render wheel
    ffmpeg -y -i replay/leg.mp4 -i replay/wheel.mp4 -filter_complex \
      "[0:v]scale=1920:540,drawtext=text=LEG-CLIMB:fontsize=30:fontcolor=white:x=20:y=20[v0];\
[1:v]scale=1920:540,tpad=stop_mode=clone:stop_duration=48.6,drawtext=text=WHEEL-R1:fontsize=30:fontcolor=white:x=20:y=20[v1];\
[v0][v1]vstack=inputs=2[v]" -map "[v]" -c:v libx264 -pix_fmt yuv420p -crf 20 replay/side_by_side.mp4
    ;;
  *) echo "usage: $0 [leg|wheel|all]"; exit 2 ;;
esac
